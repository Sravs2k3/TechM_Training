namespace MealBoxBackend.Models  // Make sure this is correct
{
    public class MealBookingRequest
    {
        public int MealId { get; set; }
    }
}
public class MealBookingRequest
{
    public int MealId { get; set; }
}